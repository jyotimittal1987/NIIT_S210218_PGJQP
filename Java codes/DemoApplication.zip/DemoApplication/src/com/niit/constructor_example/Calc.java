package com.niit.constructor_example;

public class Calc {
	int num1,num2;
	Calc(int n1, int n2)
	{
	num1=n1;
	num2=n2;
	}
	
	void display()
	{
		System.out.println(num1 + "   " + num2);
	}
}
