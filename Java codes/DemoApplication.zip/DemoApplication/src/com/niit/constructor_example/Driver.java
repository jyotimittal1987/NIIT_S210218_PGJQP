package com.niit.constructor_example;


public class Driver {

	public static void main(String[] args) {
		Calc c1=new Calc(10,20);
		c1.display();

	}

}
