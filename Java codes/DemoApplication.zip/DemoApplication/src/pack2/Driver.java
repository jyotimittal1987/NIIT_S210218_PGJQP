package pack2;
import pack1.*;
import java.sql.*;

public class Driver {

	public static void main(String[] args) {
		System.out.println("Its another package");
		Test2 t1=new Test2();
		t1.display();

	}

}
