package pack1;

import java.util.Scanner;

public class Test2 {
	int num;
public void display()
{
	System.out.println("Its method");
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter a number");
	num=sc.nextInt();
	System.out.println(num + 1);
}
}
