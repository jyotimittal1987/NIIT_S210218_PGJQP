package pack1;

public class Test3 {
void display()
{
	
	System.out.println("Its another method");
}
}
