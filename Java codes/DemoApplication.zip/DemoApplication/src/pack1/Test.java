package pack1;

public class Test {

	public static void main(String[] args) {
	System.out.println("Hello world");
	Test3 t1=new Test3();
	t1.display();

	}

}
